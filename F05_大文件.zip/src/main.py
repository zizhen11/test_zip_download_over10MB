def add(a, b):
    """返回两数之和"""
    return a + b


if __name__ == "__main__":
    print(add(1, 2))
